﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data.Linq;
using System.Reflection;
using System.Data.Linq.Mapping;
using System.Threading.Tasks;


namespace LINQ
{
    public class Class1
    {
    }
}
