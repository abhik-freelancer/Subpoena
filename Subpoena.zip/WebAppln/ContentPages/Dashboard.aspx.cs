﻿using System;

namespace WebAppln.ContentPages
{
    public partial class Dashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {        
        }
    }
}