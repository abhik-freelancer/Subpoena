﻿using System.Web.UI;

namespace WebAppln.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}